create function increase_hex(source_hex character varying, increment integer) returns character varying
    language plpgsql
as
$$
DECLARE r int;
DECLARE g int;
DECLARE b int;
BEGIN
    SELECT ('x' || substr(source_hex,2,2))::bit(8)::int + increment INTO r;
    SELECT ('x' || substr(source_hex,4,2))::bit(8)::int + increment INTO g;
    SELECT ('x' || substr(source_hex,6,2))::bit(8)::int + increment INTO b;
    SELECT CASE WHEN r > 255 THEN 255 ELSE r END INTO r;
    SELECT CASE WHEN g > 255 THEN 255 ELSE g END INTO g;
    SELECT CASE WHEN b > 255 THEN 255 ELSE b END INTO b;
    RETURN '#' || to_hex(r) || to_hex(g) || to_hex(b);
end;
$$;

alter function increase_hex(varchar, integer) owner to postgres;

